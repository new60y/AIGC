# AIGC
Very simple implementation of generative model

API similar to diffusers, providing model and schedulers

## How to use
First in root directory, just run
```shell
mkdir data
mkdir checkpoint
```

In ```./example``` just run
```shell
python train.py
```
for training and infering